'use client';

import { useEffect } from 'react';
import { InvoiceDetailView } from '@/services/billing';

interface PrintableReceiptProps {
  invoice: InvoiceDetailView;
  onClose: () => void;
}

export default function PrintableReceipt({ invoice, onClose }: PrintableReceiptProps) {
  
  useEffect(() => {
    // Attempt auto-print when modal opens
    const timer = setTimeout(() => {
      window.print();
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 print:bg-transparent print:static print:inset-auto print:block print:w-full">
      {/* Modal Container for Screen, acts as wrapper for print */}
      <div className="bg-white p-4 max-w-sm w-full mx-auto rounded shadow-2xl relative print:shadow-none print:max-w-[80mm] print:w-[80mm] print:m-0 print:p-0">
        
        {/* Close Button (Hidden in Print) */}
        <button 
          onClick={onClose}
          className="absolute top-2 right-2 text-gray-500 hover:text-black print:hidden"
        >
          ✕ Close
        </button>

        {/* Receipt Content - Styled for 80mm Thermal */}
        <div className="font-mono text-xs text-black" style={{ width: '100%' }}>
          {/* Header */}
          <div className="text-center mb-4">
            <h2 className="text-lg font-bold">CSK PHARMACY</h2>
            <p>123 Health Street, City</p>
            <p>Phone: (555) 012-3456</p>
            <div className="border-b border-dashed border-gray-400 my-2"></div>
            <h3 className="font-bold">TAX INVOICE</h3>
          </div>

          {/* Meta Info */}
          <div className="mb-2">
            <div className="flex justify-between">
              <span>Inv: {invoice.invoiceNumber}</span>
              <span>{new Date(invoice.createdAt).toLocaleDateString()}</span>
            </div>
            {invoice.customerName && (
              <div>Cust: {invoice.customerName}</div>
            )}
            {invoice.customerPhone && (
              <div>Ph: {invoice.customerPhone}</div>
            )}
          </div>

          <div className="border-b border-dashed border-gray-400 my-2"></div>

          {/* Line Items Table */}
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-gray-300">
                <th className="pb-1 w-1/2">Item/Batch</th>
                <th className="pb-1 text-right">Qty</th>
                <th className="pb-1 text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              {invoice.items.map((item, idx) => (
                <tr key={idx} className="align-top">
                  <td className="py-1">
                    <div className="font-bold">{item.medicineName}</div>
                    <div className="text-[10px] text-gray-600">{item.batchNumber} (Exp:{item.expiryDate.substring(0,7)})</div>
                  </td>
                  <td className="py-1 text-right">{item.quantity}</td>
                  <td className="py-1 text-right">{(item.totalPrice / 100).toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="border-b border-dashed border-gray-400 my-2"></div>

          {/* Summary block */}
          <div className="space-y-1 mb-2">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span>{(invoice.subtotal / 100).toFixed(2)}</span>
            </div>
            {invoice.discountAmount > 0 && (
              <div className="flex justify-between">
                <span>Discount:</span>
                <span>-{(invoice.discountAmount / 100).toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between font-bold text-sm pt-1 border-t border-gray-300">
              <span>TOTAL (Paid):</span>
              <span>{(invoice.totalAmount / 100).toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Mode:</span>
              <span>{invoice.paymentMode}</span>
            </div>
          </div>

          <div className="border-b border-dashed border-gray-400 my-2"></div>

          {/* Footer */}
          <div className="text-center text-[10px] mt-4 mb-2">
            <p>Prescription medicines dispensed.</p>
            <p>Check batch & expiry before use.</p>
            <p className="mt-2 font-bold">Thank you for your visit!</p>
          </div>
          
        </div>

        {/* Print Button for Screen (Hidden in Print) */}
        <div className="mt-6 flex justify-center print:hidden">
           <button 
             onClick={() => window.print()}
             className="bg-blue-600 text-white px-6 py-2 rounded font-bold hover:bg-blue-700 w-full"
           >
             Print Receipt Again
           </button>
        </div>

      </div>
    </div>
  );
}
