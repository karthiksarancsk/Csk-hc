const fs = require('fs');
console.log('App dir contents:', fs.readdirSync('src/app'));
console.log('Billing dir contents:', fs.readdirSync('src/app/billing'));
