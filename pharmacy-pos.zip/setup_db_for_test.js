const db = require('better-sqlite3')('pharmacy_core.db');

// Insert Medicine
const insertMed = db.prepare(`
  INSERT INTO medicines (name, generic_name, manufacturer, dosage_form, unit_type)
  VALUES ('TestMed E2E', 'Paracetamol', 'TestCo', 'Tablet', 'Strip')
`);
try {
  insertMed.run();
} catch (e) {
  // might already exist
}

const medRow = db.prepare(`SELECT id FROM medicines WHERE name = 'TestMed E2E'`).get();

// Insert Batch
const insertBatch = db.prepare(`
  INSERT INTO inventory_batches 
  (medicine_id, batch_number, expiry_date, quantity_available, purchase_price, selling_price)
  VALUES (?, 'BT-E2E-123', '2030-12-31', 100, 1000, 1500)
`);
try {
  insertBatch.run(medRow.id);
  console.log("Inserted test batch for TestMed E2E.");
} catch (e) {
   console.log("Batch might already exist", e);
}

